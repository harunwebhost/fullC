
<?php require_once('../template_module/head_section.php'); ?>
<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php require_once('../template_module/top_nav.php'); ?>
       
          <?php //require_once('../template_module/dash.php'); ?>
            <!-- /.row -->
            <?php //require_once('../template_module/show_lead.php'); ?>

            <?php 
                show_free_trail(logged_user_id(),$_SESSION['login_userntype']);
              
             ?>
            
     
      
    </div>

 
   <?php require_once('../template_module/footer.php'); ?>